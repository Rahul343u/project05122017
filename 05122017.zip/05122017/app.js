// app.js

var express = require('express');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://10.13.66.88:27017/automationframework";
var app = express();
var port = 8080;

var itemRouter = require('./routes/itemRoutes');
var bodyParser = require('body-parser');
MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  console.log('connected to database');
  });
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use('/items', itemRouter);

app.listen(port, function () {
  console.log('Server is running on port:', port);
});

app.get('/', function (req, res) {
  res.render('index');
});
