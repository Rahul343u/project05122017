var express = require('express');
var app = express();
var itemRouter = express.Router();
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://10.13.66.88:27017/automationframework";
 
itemRouter.route('/post').post(function (req, res) 
{
	  MongoClient.connect(url, function(err, db) 
	  {
		  if (err) throw err;
		   db.collection("testcases").aggregate([
		           { "$unwind": "$collection" },
				{ $lookup:
				   {
					 from: 'actions',
					 localField: 'actionid',
					 foreignField: '_id',
					 as: 'actiondetails'
				   }
				 }
				 ,{ "$unwind": "$collection" }
				 
				]).limit(1).toArray(function(err, itms)
					{
						if(err){
						  console.log(err);
						}
						else 
							 
							 {
								 res.render('item', {itms: itms});
							 }
						  console.log(itms);
					 });
				
		  });
     		  
	  });

 
itemRouter.route('/single').get(function (req, res) {
  res.render('singleItem');
});

itemRouter.route('/add').get(function (req, res) {
  res.render('addItem');
});

itemRouter.route('/add/post').post(function (req, res) {
  var item = new Item(req.body);
      item.save()
    .then(item => {
    res.redirect('/');
    })
    .catch(err => {
    res.status(400).send("unable to save to database");
    });
});
module.exports = itemRouter;